package com.example.juhaina_17f16936;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import android.view.Menu;
import android.view.MenuItem;
import android.database.Cursor;
import android.widget.Toast;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{

    EditText thedays17f16936, roomprice17f16936, username17f16936, phonenumber17f16936;
    TextView thefinalresult;
    Button calculate1, update2, delete3, read4, clear5, close6, insert7;
    ju2 DataBase1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        thedays17f16936 = (EditText) findViewById(R.id.thedays17f16936);
        roomprice17f16936 = (EditText) findViewById(R.id.roomprice17f16936);
        username17f16936 = (EditText) findViewById(R.id.username17f16936);
        phonenumber17f16936 = (EditText) findViewById(R.id.phonenumber17f16936);

        thefinalresult = (TextView) findViewById(R.id.forresult);

        calculate1 = (Button) findViewById(R.id.calculate1);
        update2 = (Button) findViewById(R.id.update2);
        delete3 = (Button) findViewById(R.id.delete3);
        read4= (Button) findViewById(R.id.read4);
        clear5= (Button) findViewById(R.id.clear5);
        close6= (Button) findViewById(R.id.close6);
        insert7= (Button) findViewById(R.id.insert7);

        DataBase1 = new ju2(this);

        calculateData();
        theUpdateData();
        theDeleteData();
        theReadData();
        theclearData();
        thecloseData();
        theinsertDate();
    }

        public void calculateData() {
            calculate1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (thedays17f16936.getText().toString().isEmpty() || roomprice17f16936.getText().toString().isEmpty()) {
                        thefinalresult.setText("There is No information. Please Insert the information");
                    } else {
                        int number1 = Integer.parseInt(thedays17f16936.getText().toString());
                        int number2 = Integer.parseInt(roomprice17f16936.getText().toString());
                        int multi = number1 * number2;
                        thefinalresult.setText(String.valueOf(multi));
                    }
                }
            });
        }

        public void theUpdateData() {
            update2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    boolean
                            update = DataBase1.updateData(thedays17f16936.getText().toString(), roomprice17f16936.getText().toString(), username17f16936.getText().toString()
                            , phonenumber17f16936.getText().toString());
                    if (update == true)
                        Toast.makeText(MainActivity.this, "information is update", Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(MainActivity.this, "information is not update", Toast.LENGTH_LONG).show();
                }

            });
        }

        public void theDeleteData() {
            delete3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Integer del=DataBase1.deleteData(thedays17f16936.getText().toString());
                    if(del>0)
                        Toast.makeText(MainActivity.this,"information is delete",Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(MainActivity.this,"information is not deleted",Toast.LENGTH_LONG).show();
                }
            });
        }

        public void theReadData() {
            read4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Cursor r=DataBase1.getAllData();
                    if(r.getCount()==0)
                    {
                        showMessage("Error", "Nothing found");
                        return;
                    }
                    StringBuffer juh=new StringBuffer();
                    while(r.moveToNext())
                    {
                        juh.append("The Days :"+r.getString(0)+"\n");
                        juh.append("The Price of The Room :"+r.getString(1)+"\n");
                        juh.append("The Username :"+r.getString(2)+"\n");
                        juh.append("The Phone Number :"+r.getString(3)+"\n");
                    }
                    showMessage("The Details of the Hotel",juh.toString());
                }
            });
        }

        public void theclearData() {
            clear5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (thedays17f16936.getText().toString().isEmpty() || roomprice17f16936.getText().toString().isEmpty() || username17f16936.getText().toString().isEmpty() ||
                            phonenumber17f16936.getText().toString().isEmpty()) {
                        thefinalresult.setText("Enter Your Information Please!!");
                    } else {
                        thedays17f16936.setText("");
                        roomprice17f16936.setText("");
                        username17f16936.setText("");
                        phonenumber17f16936.setText("");
                    }
                }
            });
        }

        public void thecloseData() {
            close6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                    System.exit(0);
                }
            });
        }

    public void theinsertDate()
    {
        insert7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean
                        insertData = DataBase1.theinsertData(thedays17f16936.getText().toString(), roomprice17f16936.getText().toString(),username17f16936.getText().toString(),
                        phonenumber17f16936.getText().toString());
                if (insertData==true)
                    Toast.makeText(MainActivity.this, "The Information are Inserted", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(MainActivity.this, "The Information are not Inserted", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void showMessage(String title,String mes)
    {
        AlertDialog.Builder ad=new AlertDialog.Builder(this);
        ad.setCancelable(true);
        ad.setTitle(title);
        ad.setMessage(mes);
        ad.show();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.layout,menu);
        return super.onCreateOptionsMenu(menu);
    }
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        int id=menuItem.getItemId();
        if(id==R.id.action_settings)
        {
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }
}

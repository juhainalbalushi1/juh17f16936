package com.example.juhaina_17f16936;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ju2 extends SQLiteOpenHelper
{
    public static final String DATABASE_NAME="ju2.DataBase";
    public static final String TABLE_NAME="JUHAINA_HOTEL";
    public static final String Column_1="DAYS";
    public static final String Column_2="THE_PRICE";
    public static final String Column_3="USERNAME";
    public static final String Column_4="PHONE_NUMBER";

    public ju2(Context context)
    {
        super(context, DATABASE_NAME,null,1);
    }

    public void onCreate(SQLiteDatabase DataBase)
    {
        DataBase.execSQL(" create table " + TABLE_NAME + "(DAYS INTEGER PRIMARY KEY AUTOINCREMENT, THE_PRICE INTEGER, " +
                "USERNAME TEXT, PHONE_NUMBER INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DataBase1, int oldVersion, int newVersion)
    {
        DataBase1.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(DataBase1);
    }
    public boolean theinsertData(String days, String theprice, String username, String phonenumber)
    {
        SQLiteDatabase DataBase1 = this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Column_1,days);
        contentValues.put(Column_2,theprice);
        contentValues.put(Column_3,username);
        contentValues.put(Column_4,phonenumber);

        long result = DataBase1.insert(TABLE_NAME, null, contentValues);
        if (result==-1)
            return false;
        else
            return true;
    }
    public boolean updateData(String days, String theprice, String username, String phonenumber)
    {
        SQLiteDatabase DataBase1 = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Column_1,days);
        contentValues.put(Column_2,theprice);
        contentValues.put(Column_3,username);
        contentValues.put(Column_4,phonenumber);

        DataBase1.update(TABLE_NAME,contentValues,"DAYS=?", new String[]{days});
        return true;
    }

    public Integer deleteData(String days)
    {
        SQLiteDatabase DataBase1 = this.getWritableDatabase();
        return DataBase1.delete(TABLE_NAME, "DAYS=?", new String[]{days});
    }

    public Cursor getAllData()
    {
        SQLiteDatabase DataBase = this.getWritableDatabase();
        Cursor cursor = DataBase.rawQuery("select * from " + TABLE_NAME, null);
        return cursor;
    }
}
